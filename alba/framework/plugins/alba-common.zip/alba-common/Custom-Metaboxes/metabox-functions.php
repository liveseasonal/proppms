<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
$textdomain = "alba";
function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cmb_';
	
    $meta_boxes[] = array(
        'id'         => 'page_setting',
        'title'      => 'Page Setting',
        'pages'      => array('page'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Selected Sidebar or Widthout Sidebar',
                'desc' => 'Type Sidebar on Blog Template',
                'id'   => $prefix . 'sidebar_page',
                'type'    => 'select',
                'options' => array(
                        array( 'name' => 'Right Sidebar', 'value' => 'right', ),
                        array( 'name' => 'Left Sidebar', 'value' => 'left', ),
                        array( 'name' => 'No Sidebar', 'value' => 'without', ),
                        array( 'name' => 'Grid Layout', 'value' => 'grid', ),
                        array( 'name' => 'Grid Layour 2', 'value' => 'grid-2', ),
                        ),
                    'default' => 'right',
            ),
            array(
                'name' => 'Image Background breadcrumb',
                'desc' => 'Input Background breadcrumb',
                'id'   => $prefix . 'page_img',
                'type'    => 'file',
            ),
            array(
                'name' => 'Page Description',
                'desc' => 'Input Page Description',
                'id'   => $prefix . 'page_desc',
                'type'    => 'text',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Author Image',
                'desc' => 'Input Author Image',
                'id'   => $prefix . 'author_img',
                'type'    => 'file',
            ),
            array(
                'name' => 'Author Title',
                'desc' => 'Input Author Title',
                'id'   => $prefix . 'author_title',
                'type'    => 'text',
            ),
            array(
                'name' => 'Author Description',
                'desc' => 'Input Author Description',
                'id'   => $prefix . 'author_desc',
                'type'    => 'textarea',
            ),
            array(
                'name' => 'Link Share Twitter',
                'desc' => 'Share post on twitter',
                'id'   => $prefix . 'post_twitter',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link Share facebook',
                'desc' => 'Share post on facebook',
                'id'   => $prefix . 'post_facebook',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link Share google',
                'desc' => 'Share post on google',
                'id'   => $prefix . 'post_google',
                'type'    => 'text',
            ),
            array(
                'name' => 'Selected Sidebar or Widthout Sidebar',
                'desc' => 'Type Sidebar',
                'id'   => $prefix . 'sidebar_post',
                'type'    => 'select',
                'options' => array(
                        array( 'name' => 'Right Sidebar', 'value' => 'right', ),
                        array( 'name' => 'Left Sidebar', 'value' => 'left', ),
                        array( 'name' => 'No Sidebar', 'value' => 'without', ),
                        ),
                    'default' => 'right',
            ),
        )
    );
    // Add other metaboxes as needed
    
	return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

} 